import numpy as np
from tensorflow.keras.models import load_model
import os
from sklearn.metrics import precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split
from model import load_data, train_model, predict_attack



class WAFSystem:
    def __init__(self):
        self.models = {}
        self.tokenizers = {}
        self.metrics = {}
        self.error_count = 0
        self.MAX_ERRORS = 5
        
    def train_all_models(self):
        """Train all models and return their metrics"""
        print("Starting model training process...")
        
        datasets = {
            "xss": "xss_dataset.csv",
            "sql": "sql_dataset.csv"
        }
        
        for threat_type, filename in datasets.items():
            try:
                print(f"\nTraining {threat_type.upper()} detection model...")
                
                # Check if dataset exists
                if not os.path.exists(filename):
                    raise FileNotFoundError(f"Dataset not found: {filename}")
                
                # Load and preprocess data
                features, labels, tokenizer = load_data(filename, threat_type)
                
                # Split data
                X_train, X_test, y_train, y_test = train_test_split(
                    features, labels, test_size=0.2, random_state=42
                )
                
                # Train model
                vocab_size = min(len(tokenizer.word_index) + 1, 10000)
                model, history = train_model(
                    X_train, y_train, 
                    X_test, y_test,
                    f'{threat_type}_model.h5',
                    vocab_size
                )
                
                # Store model and tokenizer
                self.models[threat_type] = model
                self.tokenizers[threat_type] = tokenizer
                
                # Calculate metrics
                predictions = model.predict(X_test)
                predictions = (predictions > 0.5).astype(int)
                
                self.metrics[threat_type] = {
                    'precision': precision_score(y_test, predictions),
                    'recall': recall_score(y_test, predictions),
                    'f1': f1_score(y_test, predictions),
                    'accuracy': history.history['accuracy'][-1]
                }
                
                print(f"{threat_type.upper()} model trained successfully")
                
            except Exception as e:
                print(f"Error training {threat_type} model: {str(e)}")
                raise
        
        self.error_count = 0
        print("All models trained successfully")
    
    def load_trained_models(self):
        """Load previously trained models"""
        try:
            for threat_type in ["xss", "sql"]:
                model_path = f'{threat_type}_model.h5'
                if os.path.exists(model_path):
                    self.models[threat_type] = load_model(model_path)
                    
                    # Recreate tokenizer
                    features, _, tokenizer = load_data(
                        f'{threat_type}_dataset.csv', 
                        threat_type
                    )
                    self.tokenizers[threat_type] = tokenizer
                    
                    print(f"Loaded {threat_type} model successfully")
            return True
        except Exception as e:
            print(f"Error loading models: {str(e)}")
            return False

    def process_input(self, user_input):
        """Process user input and detect threats"""
        try:
            # Determine threat type based on patterns
            sql_patterns = ['select', 'union', 'drop', '--', ';']
            xss_patterns = ['<script>', 'javascript:', 'onerror=', 'onload=']
            
            input_lower = user_input.lower()
            
            if any(pattern in input_lower for pattern in sql_patterns):
                threat_type = "sql"
            elif any(pattern in input_lower for pattern in xss_patterns):
                threat_type = "xss"
            else:
                threat_type = "xss"
            
            result = predict_attack(
                self.models[threat_type],
                self.tokenizers[threat_type],
                user_input
            )
            
            self.error_count = max(0, self.error_count - 1)
            return result, threat_type
            
        except Exception as e:
            self.error_count += 1
            if self.error_count >= self.MAX_ERRORS:
                print("Multiple errors detected. Initiating model retraining...")
                self.train_all_models()
            raise e

def main():
    """Main function to run the WAF"""
    print("Initializing Web Application Firewall...")
    
    waf_system = WAFSystem()
    
    # Try to load existing models or train new ones
    if not waf_system.load_trained_models():
        print("No existing models found. Training new models...")
        waf_system.train_all_models()
    
    print("\nWAF is ready. Commands:")
    print("- Enter text to analyze")
    print("- Type 'metrics' to see model performance")
    print("- Type 'retrain' to force model retraining")
    print("- Type 'quit' to exit")
    
    while True:
        try:
            print("\nEnter request data to classify:")
            user_input = input().strip()
            
            if user_input.lower() == 'quit':
                print("Exiting WAF...")
                break
                
            if user_input.lower() == 'metrics':
                print("\n=== Model Performance Metrics ===")
                for threat_type, metric in waf_system.metrics.items():
                    print(f"\n{threat_type.upper()} Detection Model:")
                    print(f"Precision: {metric['precision']:.4f}")
                    print(f"Recall: {metric['recall']:.4f}")
                    print(f"F1 Score: {metric['f1']:.4f}")
                    print(f"Accuracy: {metric['accuracy']:.4f}")
                continue
                
            if user_input.lower() == 'retrain':
                print("Initiating model retraining...")
                waf_system.train_all_models()
                continue
            
            result, threat_type = waf_system.process_input(user_input)
            
            print("\n=== Detection Result ===")
            print(f"Threat Type: {threat_type.upper()}")
            print(f"Result: {result['result']}")
            print("=====================")
            
        except FileNotFoundError as e:
            print(f"\nError: Required dataset not found - {str(e)}")
            print("Please ensure the dataset files are in the correct location.")
        except ValueError as e:
            print(f"\nError: Invalid input or configuration - {str(e)}")
        except Exception as e:
            print(f"\nError: {str(e)}")
            print(f"Unexpected error: {str(e)}", exc_info=True)

if __name__ == "__main__":
    main()