import pandas as pd
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, Dropout, Embedding
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
def load_data(filename, threat_type):
    """
    Load and preprocess dataset based on threat type
    
    Args:
        filename (str): Path to the dataset file
        threat_type (str): Type of threat ('xss' or 'sql')
        
    Returns:
        tuple: (features, labels, tokenizer)
    """
    try:
        df = pd.read_csv(filename)
        if df.empty:
            raise ValueError(f"Empty dataset: {filename}")
            
        # Determine text column
        text_column = 'request_data' if 'request_data' in df.columns else 'query'
        if text_column not in df.columns or 'label' not in df.columns:
            raise ValueError(f"Missing required columns in {filename}")
        
        # Prepare text data
        texts = df[text_column].fillna('').astype(str)
        labels = df['label'].values
        
        # Initialize and fit tokenizer
        tokenizer = Tokenizer(num_words=10000, oov_token='<UNK>')
        tokenizer.fit_on_texts(texts)
        
        # Convert to sequences and pad
        sequences = tokenizer.texts_to_sequences(texts)
        features_padded = pad_sequences(sequences, maxlen=100)
        
        return features_padded, labels, tokenizer
        
    except Exception as e:
        print(f"Error loading data from {filename}: {str(e)}")
        raise

def build_model(vocab_size, max_length=100):
    """
    Build LSTM model architecture
    
    Args:
        vocab_size (int): Size of vocabulary for embedding layer
        max_length (int): Maximum sequence length
        
    Returns:
        Sequential: Compiled Keras model
    """
    model = Sequential([
        Embedding(vocab_size, 32, input_length=max_length),
        LSTM(64, return_sequences=True),
        Dropout(0.3),
        LSTM(32),
        Dropout(0.3),
        Dense(16, activation='relu'),
        Dense(1, activation='sigmoid')
    ])
    
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def train_model(X_train, y_train, X_test, y_test, model_name, vocab_size):
    """
    Train LSTM model and save it
    
    Args:
        X_train: Training features
        y_train: Training labels
        X_test: Test features
        y_test: Test labels
        model_name (str): Name for saving the model
        vocab_size (int): Size of vocabulary for embedding layer
        
    Returns:
        tuple: (trained model, training history)
    """
    try:
        model = build_model(vocab_size)
        
        # Train with validation
        history = model.fit(
            X_train, y_train,
            validation_data=(X_test, y_test),
            epochs=5,
            batch_size=32,
            verbose=1
        )
        
        # Save model
        model.save(model_name)
        print(f"Model saved successfully as {model_name}")
        
        return model, history
        
    except Exception as e:
        print(f"Error training model: {str(e)}")
        raise

def predict_attack(model, tokenizer, request_data):
    """
    Predict if input is an attack
    
    Args:
        model: Trained LSTM model
        tokenizer: Fitted tokenizer
        request_data: Input data to classify
        
    Returns:
        dict: Prediction results
    """
    try:
        # Preprocess input
        sequences = tokenizer.texts_to_sequences([request_data])
        padded_seq = pad_sequences(sequences, maxlen=100)
        
        # Get prediction
        prediction = model.predict(padded_seq, verbose=0)
        probability = prediction[0][0]
        
        return {
            'result': "Attack detected" if probability >= 0.5 else "Normal request",
            'probability': float(probability)
        }
        
    except Exception as e:
        print(f"Error in prediction: {str(e)}")
        raise