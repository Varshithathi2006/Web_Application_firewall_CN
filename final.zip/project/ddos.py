import random
import pandas as pd
from datetime import datetime, timedelta

# Generate a synthetic DDoS dataset with normal and attack data
def generate_ddos_data(num_samples=300):
    ips = [f"192.168.1.{random.randint(1, 255)}" for _ in range(num_samples)]
    labels = []
    request_counts = []
    packet_sizes = []
    timestamps = []

    for i in range(num_samples):
        # Random normal or DDoS attack generation
        is_attack = random.random() < 0.3  # 30% chance of being an attack
        labels.append("0" if is_attack else "1")

        # Simulate requests: DDoS attacks have a much higher request count and packet size
        if is_attack:
            request_count = random.randint(100, 1000)  # Attack typically has a lot of requests
            packet_size = random.randint(500, 1500)  # Large packets during DDoS
        else:
            request_count = random.randint(1, 20)  # Normal traffic has fewer requests
            packet_size = random.randint(100, 500)  # Smaller packet sizes for normal traffic
        
        request_counts.append(request_count)
        packet_sizes.append(packet_size)
        
        # Simulate timestamps: Spread the timestamps within the past 24 hours
        timestamp = datetime.now() - timedelta(minutes=random.randint(0, 1440))
        timestamps.append(timestamp)

    # Create DataFrame
    df = pd.DataFrame({
        "IP Address": ips,
        "Request Count": request_counts,
        "Packet Size": packet_sizes,
        "Timestamp": timestamps,
        "Label": labels
    })
    
    return df

# Generate and save dataset to CSV
ddos_df = generate_ddos_data(300)
ddos_df.to_csv("ddos_dataset.csv", index=False)
print("DDoS dataset generated and saved as 'ddos_dataset.csv'.")
