import pandas as pd

# Function to load the queries, label them, and take only 500 from each file
def load_and_label_data(bad_file, good_file, num_queries=500):
    # Load bad and good queries
    with open(bad_file, 'r') as file:
        bad_queries = file.readlines()[:num_queries]  # Take only the first 'num_queries' queries
    
    with open(good_file, 'r') as file:
        good_queries = file.readlines()[:num_queries]  # Take only the first 'num_queries' queries

    # Create DataFrames for both sets of queries
    bad_df = pd.DataFrame(bad_queries, columns=['query'])
    good_df = pd.DataFrame(good_queries, columns=['query'])

    # Add a label column: 0 for bad queries, 1 for good queries
    bad_df['label'] = 0
    good_df['label'] = 1

    # Concatenate the DataFrames
    combined_df = pd.concat([bad_df, good_df], ignore_index=True)

    # Shuffle the combined DataFrame
    combined_df = combined_df.sample(frac=1).reset_index(drop=True)

    return combined_df

# File paths for your input datasets
badqueries_file = 'badqueries.txt'
goodqueries_file = 'goodqueries.txt'

# Load and label the data, taking only 500 queries from each
combined_data = load_and_label_data(badqueries_file, goodqueries_file)

# Save the combined data to a CSV file
combined_data.to_csv('combined_queries.csv', index=False)

print("Combined data (500 queries from each) saved to 'combined_queries_500.csv'")
