# LSTM-based Web Application Firewall (WAF)

This project implements a Web Application Firewall (WAF) using an LSTM model to detect DDoS, XSS, and SQL Injection attacks. It combines policy-based detection with machine learning to enhance security.

## Requirements
- Python 3.7+
- TensorFlow, Pandas, NumPy, Scikit-learn

Install dependencies using:
